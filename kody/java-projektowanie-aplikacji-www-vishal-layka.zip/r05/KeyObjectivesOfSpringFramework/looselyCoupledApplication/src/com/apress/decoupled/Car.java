package com.apress.decoupled;

public class Car implements Vehicle {

	public String drive() {
		return "jazda samochodem";
	}

}

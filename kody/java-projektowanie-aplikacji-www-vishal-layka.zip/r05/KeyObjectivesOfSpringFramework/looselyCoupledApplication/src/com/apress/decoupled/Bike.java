package com.apress.decoupled;

public class Bike implements Vehicle {
	public String drive() {
		return "jazda motocyklem";
	}
}

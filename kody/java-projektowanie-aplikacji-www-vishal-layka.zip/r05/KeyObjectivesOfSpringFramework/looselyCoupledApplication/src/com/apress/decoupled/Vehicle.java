package com.apress.decoupled;

public interface Vehicle {
	public String drive();
}

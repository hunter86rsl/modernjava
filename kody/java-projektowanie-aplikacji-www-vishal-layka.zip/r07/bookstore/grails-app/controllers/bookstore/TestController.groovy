package bookstore

class TestController {

    def index() { }
}

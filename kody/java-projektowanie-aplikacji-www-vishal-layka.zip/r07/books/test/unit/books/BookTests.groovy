package books



import grails.test.mixin.*
import org.junit.*

/**
 * Zobacz API dla {@link grails.test.mixin.domain.DomainClassUnitTestMixin} w celu uzyskania instrukcji obsługi
 */
@TestFor(Book)
class BookTests {

    void testSomething() {
       fail "Zaimplementuj mnie"
    }
}

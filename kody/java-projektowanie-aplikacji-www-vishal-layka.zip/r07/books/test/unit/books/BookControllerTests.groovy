package books



import grails.test.mixin.*
import org.junit.*

/**
 * Zobacz API dla {@link grails.test.mixin.web.ControllerUnitTestMixin} w celu uzyskania instrukcji obsługi
 */
@TestFor(BookController)
class BookControllerTests {

    void testSomething() {
       fail "Zaimplementuj mnie"
    }
}

package books



import grails.test.mixin.*
import org.junit.*

/**
 * Zobacz API dla {@link grails.test.mixin.domain.DomainClassUnitTestMixin} w celu uzyskania instrukcji obsługi
 */
@TestFor(Author)
class AuthorTests {

    void testSomething() {
       fail "Zaimplementuj mnie"
    }
}

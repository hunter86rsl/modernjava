package helloworld



import grails.test.mixin.*
import org.junit.*

/**
 * Zobacz API dla {@link grails.test.mixin.web.ControllerUnitTestMixin} w celu uzyskania instrukcji obsługi
 */
@TestFor(HelloController)
class HelloControllerTests {

    void testSomething() {
       fail "Zaimplementuj mnie"
    }
}

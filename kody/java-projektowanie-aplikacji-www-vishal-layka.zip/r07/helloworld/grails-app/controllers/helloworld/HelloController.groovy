﻿package helloworld

class HelloController {

def index() { render "Witaj, świecie!" } 
}
